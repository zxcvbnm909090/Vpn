package com.mahmoud.vpn;

import android.net.VpnService;
import android.content.Intent;
import android.os.ParcelFileDescriptor;

/*
 * هيكل أولي فقط.
 * لا ينشئ اتصال SSH/SSL ولا يوجّه حركة الإنترنت حالياً.
 * يجب دمج عميل نفق موثوق، والتحقق من TLS، ثم تمرير الحزم بين TUN والنفق.
 */
public class TunnelVpnService extends VpnService {
    private ParcelFileDescriptor tunInterface;

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        // لا تبدأ نفقاً فارغاً ولا تدّعِ أن الاتصال متصل.
        stopSelf();
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        try {
            if (tunInterface != null) tunInterface.close();
        } catch (Exception ignored) { }
        super.onDestroy();
    }
}
