package com.mahmoud.vpn;

import android.app.Activity;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private static final int VPN_REQUEST = 1001;
    private TextView status;
    private Button connect;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(28, 48, 28, 28);
        root.setBackgroundColor(Color.rgb(9, 6, 17));

        TextView title = new TextView(this);
        title.setText("MAHMOUD VPN");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        root.addView(title, new LinearLayout.LayoutParams(-1, 80));

        TextView server = new TextView(this);
        server.setText("SERVER\n102.129.137.131 : 443\nSSH + SSL");
        server.setTextColor(Color.LTGRAY);
        server.setTextSize(16);
        server.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, 120);
        sp.topMargin = 28;
        root.addView(server, sp);

        status = new TextView(this);
        status.setText("DISCONNECTED");
        status.setTextColor(0xFFFFB74D);
        status.setTextSize(17);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, 60);
        stp.topMargin = 18;
        root.addView(status, stp);

        connect = new Button(this);
        connect.setText("CONNECT");
        connect.setTextColor(Color.WHITE);
        connect.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF7E22CE));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, 64);
        bp.topMargin = 24;
        root.addView(connect, bp);

        TextView note = new TextView(this);
        note.setText("نسخة تجريبية للواجهة فقط. يلزم إعداد عميل SSH/SSL قبل الاتصال الحقيقي.");
        note.setTextColor(0xFFB9AFC7);
        note.setTextSize(13);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = 28;
        root.addView(note, np);

        setContentView(root);

        connect.setOnClickListener(v -> {
            Intent prepare = VpnService.prepare(this);
            if (prepare != null) startActivityForResult(prepare, VPN_REQUEST);
            else onActivityResult(VPN_REQUEST, RESULT_OK, null);
        });
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST) {
            if (resultCode == RESULT_OK) {
                status.setText("VPN PERMISSION GRANTED");
                Toast.makeText(this,
                    "تم منح الإذن. النفق غير مفعّل بعد؛ يلزم دمج عميل SSH/SSL.",
                    Toast.LENGTH_LONG).show();
            } else {
                status.setText("PERMISSION DENIED");
            }
        }
    }
}
