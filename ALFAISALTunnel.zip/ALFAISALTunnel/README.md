# ALFAISAL Tunnel+ (Android, Kotlin + Compose + WireGuard)
Build: open in Android Studio (Hedgehog+, JDK 17) → set `API_BASE_URL` in gradle.properties → Build > Build APK.

## How the real VPN works
App generates a WireGuard keypair on-device (private key stays in EncryptedSharedPreferences), sends only the PUBLIC key
to your backend; backend adds it as a peer on your WireGuard server and returns the tunnel parameters. No secrets are in the APK.

## Backend API you must host (HTTPS, Bearer account token; 403 when subscription expired)
- GET  /v1/me       -> {plan:"free|premium", expiresAt:<unix s>, telegram:"https://t.me/..."}
- GET  /v1/servers  -> {servers:[{id,name,flag,online,mbps}]}   (admin adds/removes/renames these => no new APK needed)
- POST /v1/connect  {serverId, publicKey} -> {address:"10.8.0.x/32", dns, serverPublicKey, endpoint:"host:51820", allowedIps}
  (backend runs `wg set wg0 peer <publicKey> allowed-ips <address>` on that server, only if subscription is active)
Admin panel = web UI over the same DB (servers CRUD, users, add time, status).
