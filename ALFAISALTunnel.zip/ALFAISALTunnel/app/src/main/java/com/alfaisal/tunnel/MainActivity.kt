package com.alfaisal.tunnel

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Purple = Color(0xFF8B3DFF); private val Bg = Color(0xFF0A0612); private val Card = Color(0xFF16101F)

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) { super.onCreate(s)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Purple, background = Bg, surface = Card)) { App() } } }
}

@Composable fun App() {
    val ctx = LocalContext.current; val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var token by remember { mutableStateOf(Store.get(ctx, "token") ?: "") }
    var servers by remember { mutableStateOf(listOf<Srv>()) }
    var selected by remember { mutableStateOf<Srv?>(null) }
    var me by remember { mutableStateOf<Me?>(null) }
    var state by remember { mutableStateOf(0) } // 0 off, 1 connecting, 2 on
    var seconds by remember { mutableStateOf(0L) }
    var tx by remember { mutableStateOf(0L) }; var rx by remember { mutableStateOf(0L) }
    val logs = remember { mutableStateListOf<String>() }
    var picker by remember { mutableStateOf(false) }
    fun log(m: String) { logs.add(0, "${java.text.SimpleDateFormat("HH:mm:ss").format(java.util.Date())}  $m") }

    fun refresh() { if (token.isBlank()) return
        scope.launch { try { val t = token
            val (m, s) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { Api.me(t) to Api.servers(t) }
            me = m; servers = s; if (selected == null) selected = s.firstOrNull { it.online }
        } catch (e: Exception) { log("Error: ${e.message}") } } }
    LaunchedEffect(token) { refresh() }
    LaunchedEffect(state) { while (state == 2) { delay(1000); seconds++; VpnManager.bytes(ctx).let { tx = it.first; rx = it.second } } ; if (state == 0) seconds = 0 }

    fun connect() { val srv = selected ?: return
        scope.launch { state = 1; log("Connecting to ${srv.name}")
            try { VpnManager.start(ctx, token, srv.id); state = 2; log("Connected") }
            catch (e: Exception) { state = 0; log("Failed: ${e.message}") } } }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { if (it.resultCode == Activity.RESULT_OK) connect() else log("VPN permission denied") }
    fun toggle() {
        if (state == 2) { scope.launch { VpnManager.stop(ctx); state = 0; log("Disconnected") }; return }
        if (token.isBlank()) { log(ctx.getString(R.string.no_token)); tab = 3; return }
        val i = VpnManager.permissionIntent(ctx); if (i != null) perm.launch(i) else connect()
    }

    Scaffold(containerColor = Bg, bottomBar = {
        NavigationBar(containerColor = Card) {
            listOf(Icons.Default.Home to R.string.home, Icons.Default.List to R.string.logs, Icons.Default.Settings to R.string.settings,
                Icons.Default.Send to R.string.telegram, Icons.Default.Info to R.string.about).forEachIndexed { i, (ic, t) ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i }, icon = { Icon(ic, null) }, label = { Text(stringResource(t), fontSize = 9.sp) }) } }
    }) { pad -> Box(Modifier.padding(pad).fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF1B0B33), Bg)))) {
        when (tab) {
            0 -> Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(stringResource(R.string.app_name), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.height(8.dp))
                Text(stringResource(when (state) { 2 -> R.string.connected; 1 -> R.string.connecting; else -> R.string.disconnected }),
                    color = if (state == 2) Color(0xFF3DDC84) else Color.Gray)
                Spacer(Modifier.height(28.dp))
                Box(Modifier.size(190.dp).shadow(if (state == 2) 40.dp else 8.dp, CircleShape, ambientColor = Purple, spotColor = Purple)
                    .clip(CircleShape).background(Brush.radialGradient(listOf(Purple, Color(0xFF3B1480))))
                    .clickable(enabled = state != 1) { toggle() }, contentAlignment = Alignment.Center) {
                    Text(stringResource(if (state == 2) R.string.stop else R.string.start), fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White) }
                Spacer(Modifier.height(20.dp))
                Text("%02d:%02d:%02d".format(seconds / 3600, seconds / 60 % 60, seconds % 60), fontSize = 30.sp, color = Color.White)
                Spacer(Modifier.height(16.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Stat(stringResource(R.string.upload), fmt(tx), Modifier.weight(1f)); Stat(stringResource(R.string.download), fmt(rx), Modifier.weight(1f)) }
                Spacer(Modifier.height(12.dp))
                Stat(stringResource(R.string.server), selected?.let { "${it.flag} ${it.name}" } ?: "—", Modifier.fillMaxWidth().clickable { picker = true })
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Stat(stringResource(R.string.remaining), me?.let { remain(it.expiresAt) + "  (${it.plan})" } ?: "—", Modifier.weight(1f))
                    Button(onClick = { me?.telegram?.takeIf { it.isNotBlank() }?.let { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } }) { Text(stringResource(R.string.add_time)) } }
            }
            1 -> LazyColumn(Modifier.padding(16.dp)) { items(logs) { Text(it, color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp)) } }
            2 -> Column(Modifier.padding(20.dp)) {
                var t by remember { mutableStateOf(token) }
                OutlinedTextField(t, { t = it }, label = { Text(stringResource(R.string.token)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(12.dp))
                Button(onClick = { Store.put(ctx, "token", t.trim()); token = t.trim() }) { Text(stringResource(R.string.save)) } }
            3 -> Center { Button(onClick = { me?.telegram?.takeIf { it.isNotBlank() }?.let { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } }) { Text(stringResource(R.string.telegram)) } }
            else -> Center { Text(stringResource(R.string.about_text), color = Color.White, modifier = Modifier.padding(24.dp)) }
        } } }

    if (picker) ModalBottomSheet(onDismissRequest = { picker = false }, containerColor = Card) {
        var q by remember { mutableStateOf("") }
        OutlinedTextField(q, { q = it }, label = { Text(stringResource(R.string.search)) }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        LazyColumn { items(servers.filter { it.name.contains(q, true) }) { s ->
            Row(Modifier.fillMaxWidth().clickable(enabled = s.online) { selected = s; picker = false }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${s.flag} ${s.name}", color = Color.White, modifier = Modifier.weight(1f))
                Text(if (s.online) "● ${s.mbps} Mbps" else "● offline", color = if (s.online) Color(0xFF3DDC84) else Color.Red, fontSize = 12.sp) } } }
    }
}
@Composable fun Center(c: @Composable () -> Unit) = Box(Modifier.fillMaxSize(), Alignment.Center) { c() }
@Composable fun Stat(l: String, v: String, m: Modifier) = Column(m.clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp)).background(Card).padding(14.dp)) {
    Text(l, color = Color.Gray, fontSize = 11.sp); Text(v, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
fun fmt(b: Long) = if (b > 1 shl 20) "%.1f MB".format(b / 1048576.0) else "%.0f KB".format(b / 1024.0)
fun remain(exp: Long): String { val s = (exp - System.currentTimeMillis() / 1000).coerceAtLeast(0); return "${s / 86400}d ${s / 3600 % 24}h ${s / 60 % 60}m" }
