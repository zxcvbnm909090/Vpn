package com.alfaisal.tunnel

import android.content.Context
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.Config
import com.wireguard.config.InetEndpoint
import com.wireguard.config.Interface
import com.wireguard.crypto.KeyPair
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Real tunnel: WireGuard GoBackend runs on top of Android VpnService. */
object VpnManager {
    private var backend: GoBackend? = null
    val tunnel = object : Tunnel {
        override fun getName() = "alfaisal"
        override fun onStateChange(newState: Tunnel.State) {}
    }
    private fun be(c: Context) = backend ?: GoBackend(c.applicationContext).also { backend = it }

    /** Non-null Intent => must start it so the user grants the system VPN permission. */
    fun permissionIntent(c: Context) = GoBackend.VpnService.prepare(c)

    suspend fun start(c: Context, token: String, serverId: String) = withContext(Dispatchers.IO) {
        val priv = Store.get(c, "wg_priv") ?: KeyPair().privateKey.toBase64().also { Store.put(c, "wg_priv", it) }
        val pub = KeyPair(com.wireguard.crypto.Key.fromBase64(priv)).publicKey.toBase64()
        val p = Api.connect(token, serverId, pub) // server registers our public key and returns the peer data
        val cfg = Config.Builder()
            .setInterface(Interface.Builder().parsePrivateKey(priv).parseAddresses(p.address).parseDnsServers(p.dns).build())
            .addPeer(com.wireguard.config.Peer.Builder().parsePublicKey(p.serverKey)
                .setEndpoint(InetEndpoint.parse(p.endpoint)).parseAllowedIPs(p.allowed).parsePersistentKeepalive("25").build())
            .build()
        be(c).setState(tunnel, Tunnel.State.UP, cfg)
    }
    suspend fun stop(c: Context) = withContext(Dispatchers.IO) { be(c).setState(tunnel, Tunnel.State.DOWN, null) }
    fun bytes(c: Context): Pair<Long, Long> = try { be(c).getStatistics(tunnel).let { it.totalTx() to it.totalRx() } } catch (e: Exception) { 0L to 0L }
}
