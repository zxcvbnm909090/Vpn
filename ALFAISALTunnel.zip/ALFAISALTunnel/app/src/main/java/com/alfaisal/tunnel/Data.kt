package com.alfaisal.tunnel

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class Srv(val id: String, val name: String, val flag: String, val online: Boolean, val mbps: Int)
data class Me(val plan: String, val expiresAt: Long, val telegram: String)
data class Peer(val address: String, val dns: String, val serverKey: String, val endpoint: String, val allowed: String)

/** Tokens and the device private key live only in encrypted storage; nothing secret is compiled in. */
object Store {
    private fun p(c: Context) = EncryptedSharedPreferences.create(c, "secure",
        MasterKey.Builder(c).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
    fun get(c: Context, k: String) = p(c).getString(k, null)
    fun put(c: Context, k: String, v: String) = p(c).edit().putString(k, v).apply()
}

object Api {
    private fun call(tok: String, path: String, body: JSONObject? = null): JSONObject {
        val c = URL(BuildConfig.API_BASE_URL + path).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        c.setRequestProperty("Authorization", "Bearer $tok")
        if (body != null) { c.requestMethod = "POST"; c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json"); c.outputStream.use { it.write(body.toString().toByteArray()) } }
        val code = c.responseCode
        val txt = (if (code < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code == 401) error("Invalid or expired token")
        if (code == 403) error("Subscription expired")
        if (code >= 400) error("Server error $code")
        return JSONObject(txt)
    }
    fun me(t: String) = call(t, "/v1/me").let { Me(it.getString("plan"), it.getLong("expiresAt"), it.optString("telegram")) }
    fun servers(t: String): List<Srv> = call(t, "/v1/servers").getJSONArray("servers").let { a ->
        (0 until a.length()).map { a.getJSONObject(it).let { o -> Srv(o.getString("id"), o.getString("name"), o.optString("flag"), o.optBoolean("online", true), o.optInt("mbps")) } } }
    fun connect(t: String, id: String, pub: String) = call(t, "/v1/connect", JSONObject().put("serverId", id).put("publicKey", pub)).let {
        Peer(it.getString("address"), it.getString("dns"), it.getString("serverPublicKey"), it.getString("endpoint"), it.optString("allowedIps", "0.0.0.0/0, ::/0")) }
}
