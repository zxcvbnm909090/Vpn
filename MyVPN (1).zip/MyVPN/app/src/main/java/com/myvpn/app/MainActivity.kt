package com.myvpn.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private lateinit var servers: List<Server>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        servers = ServerRepository.load(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { HomeScreen(servers) }
            }
        }
    }

    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    private fun HomeScreen(servers: List<Server>) {
        var selected by remember { mutableStateOf(servers.firstOrNull()) }
        var showPicker by remember { mutableStateOf(false) }
        var connected by remember { mutableStateOf(false) }

        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = if (connected) "متصل" else "غير متصل",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(Modifier.height(56.dp))

            Button(
                onClick = {
                    // محرك الاتصال لم يُضف بعد
                    Toast.makeText(this@MainActivity, "محرك الاتصال لم يُضف بعد", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.size(160.dp)
            ) {
                Text("اتصال")
            }

            Spacer(Modifier.height(32.dp))
            OutlinedButton(onClick = { showPicker = true }) {
                Text("السيرفر: ${selected?.name ?: "-"}")
            }
        }

        if (showPicker) {
            ModalBottomSheet(onDismissRequest = { showPicker = false }) {
                LazyColumn(contentPadding = PaddingValues(16.dp)) {
                    items(servers) { s ->
                        ListItem(
                            headlineContent = { Text(s.name) },
                            supportingContent = { Text(s.address) },
                            modifier = Modifier.clickable {
                                selected = s
                                showPicker = false
                            }
                        )
                    }
                }
            }
        }
    }
}
