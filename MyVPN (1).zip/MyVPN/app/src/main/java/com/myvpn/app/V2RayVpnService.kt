package com.myvpn.app

import android.app.Service
import android.content.Intent
import android.net.VpnService

/**
 * خدمة VPN مؤقتة.
 * محرك Xray لم يُضف بعد، لذلك لا تفتح واجهة VPN حتى لا ينقطع الإنترنت على الهاتف.
 * عند إضافة المحرك، يتم وضع منطق الاتصال هنا.
 */
class V2RayVpnService : VpnService() {

    companion object {
        const val ACTION_CONNECT = "com.myvpn.app.CONNECT"
        const val ACTION_DISCONNECT = "com.myvpn.app.DISCONNECT"
        const val EXTRA_SERVER_JSON = "server_config"
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        stopSelf()
        return START_NOT_STICKY
    }
}
